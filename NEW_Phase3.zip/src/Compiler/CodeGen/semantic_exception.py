class SemanticException(Exception):
    pass
