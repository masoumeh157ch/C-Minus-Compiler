import string


class TokenState:
    def __init__(self, state_id: int, terminal_type: int, token_type_id: int = 0, error_msg: str = "Invalid input"):
        self.state_id = state_id
        self.error_msg = error_msg
        self.transitions = {}
        self.token_type_id = token_type_id
        
        # terminal_type values:
        # 0: non-terminal state
        # 1: terminal state (non-backtracking)
        # 2: terminal state (backtracking)
        self.terminal_type = terminal_type

    def add_transition(self, input_char: str, target_state: int):
        self.transitions[input_char] = target_state

    def get_next_state(self, input_char: str) -> int:
        if input_char in self.transitions:
            return self.transitions[input_char]
        elif "all" in self.transitions and input_char != "$":
            return self.state_id
        return -1

    def get_error(self, input_char: str = "") -> str:
        return self.error_msg


char_categories = [
    [";", ":", ",", "[", "]", "(", ")", "{", "}", "+", "-", "<"],  # 0: symbols
    ["*"],                                                          # 1: star
    ["="],                                                          # 2: equal
    ["/"],                                                          # 3: slash
    ["\n", "\r", "\t", "\v", "\f", " "],                           # 4: whitespaces
    ["$"],                                                          # 5: EOF
    list(string.ascii_letters),                                     # 6: letters
    ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],            # 7: digits
    ["all"]                                                         # 8: all other chars
]


def setup_transitions(category_ids: list[int], target_states: list[int], state: TokenState):
    if len(category_ids) != len(target_states):
        print("Error: category_ids and target_states must have the same length")
        return

    for i in range(len(category_ids)):
        for char in char_categories[category_ids[i]]:
            state.add_transition(char, target_states[i])


class LexicalAnalyzer:
    def __init__(self, input_file, output_file, lexical_errors_file, symbol_table_file, symbol_table):
        self.input_file = input_file
        self.output_file = output_file
        self.lexical_errors_file = lexical_errors_file
        self.symbol_table_file = symbol_table_file
        self.symbol_table = symbol_table
        
        self.token_types = {
            1: "NUM", 
            2: "ID", 
            3: "KEYWORD", 
            4: "SYMBOL", 
            5: "COMMENT", 
            6: "WHITESPACE"
        }
        
        self.reserved_keywords = ["if", "else", "void", "int", "repeat", "break", "until", "return"]
        
        self.identifiers_list = []
        self.symbol_table_pos = 0
        self.symbol_table_ready = False
        
        self.line_num = 0
        self.curr_line = ""
        self.eof_reached = False
        self.comment_text = ""
        self.comment_line_num = -1
        
        self.need_line_update = True
        
        self.cursor_start = 0
        self.cursor_end = -1
        self.error_list = []
        
        self.states = []
        self.initialize_states()

    def initialize_states(self):
        # State 0: Initial state
        s = TokenState(state_id=0, terminal_type=0)
        setup_transitions(
            category_ids=[7, 5, 6, 0, 2, 3, 4, 1], 
            target_states=[1, 0, 3, 5, 6, 9, 16, 11],
            state=s
        )
        self.states.append(s)
        
        # State 1: Number state
        s = TokenState(state_id=1, terminal_type=0, error_msg="Invalid number")
        setup_transitions(
            category_ids=[0, 1, 2, 3, 4, 5, 7], 
            target_states=[2, 2, 2, 2, 2, 2, 1],
            state=s
        )
        self.states.append(s)
        
        # State 2: Accept number
        s = TokenState(state_id=2, terminal_type=2, token_type_id=1)
        self.states.append(s)
        
        # State 3: Identifier state
        s = TokenState(state_id=3, terminal_type=0)
        setup_transitions(
            category_ids=[0, 1, 2, 3, 4, 5, 6, 7], 
            target_states=[4, 4, 4, 4, 4, 4, 3, 3],
            state=s
        )
        self.states.append(s)
        
        # State 4: Accept identifier
        s = TokenState(state_id=4, terminal_type=2, token_type_id=2)
        self.states.append(s)
        
        # State 5: Accept symbol
        s = TokenState(state_id=5, terminal_type=1, token_type_id=4)
        self.states.append(s)
        
        # State 6: Equal state
        s = TokenState(state_id=6, terminal_type=0)
        setup_transitions(
            category_ids=[0, 1, 2, 3, 4, 6, 7], 
            target_states=[7, 7, 8, 7, 7, 7, 7],
            state=s
        )
        self.states.append(s)
        
        # State 7: Accept symbol (=)
        s = TokenState(state_id=7, terminal_type=2, token_type_id=4)
        self.states.append(s)
        
        # State 8: Accept symbol (==)
        s = TokenState(state_id=8, terminal_type=1, token_type_id=4)
        self.states.append(s)
        
        # State 9: Slash state
        s = TokenState(state_id=9, terminal_type=0)
        setup_transitions(
            category_ids=[1, 0, 2, 3, 4, 5, 6, 7], 
            target_states=[13, 10, 10, 10, 10, 10, 10, 10],
            state=s
        )
        self.states.append(s)
        
        # State 10: Accept symbol (/)
        s = TokenState(state_id=10, terminal_type=2, token_type_id=4)
        self.states.append(s)
        
        # State 11: Star state
        s = TokenState(state_id=11, terminal_type=0, error_msg="Unmatched comment")
        setup_transitions(
            category_ids=[0, 1, 2, 4, 5, 6, 7], 
            target_states=[12, 12, 12, 12, 12, 12, 12],
            state=s
        )
        self.states.append(s)
        
        # State 12: Accept symbol (*)
        s = TokenState(state_id=12, terminal_type=2, token_type_id=4)
        self.states.append(s)
        
        # State 13: Comment state
        s = TokenState(state_id=13, terminal_type=0, error_msg="Unclosed comment")
        setup_transitions(
            category_ids=[0, 1, 2, 3, 4, 6, 7, 8], 
            target_states=[13, 14, 13, 13, 13, 13, 13, 13],
            state=s
        )
        self.states.append(s)
        
        # State 14: Star in comment
        s = TokenState(state_id=14, terminal_type=0, error_msg="Unclosed comment")
        setup_transitions(
            category_ids=[0, 1, 2, 3, 4, 6, 7], 
            target_states=[13, 14, 13, 15, 13, 13, 13],
            state=s
        )
        self.states.append(s)
        
        # State 15: Accept comment
        s = TokenState(state_id=15, terminal_type=1, token_type_id=5)
        self.states.append(s)
        
        # State 16: Accept whitespace
        s = TokenState(state_id=16, terminal_type=1, token_type_id=6)
        self.states.append(s)

    def read_next_char(self):
        line_changed = False
        
        if self.eof_reached:
            return '$', line_changed
            
        if self.line_num == 0 or self.cursor_end >= len(self.curr_line) - 1:
            new_line = self.input_file.readline()
            
            if len(new_line) == 0:
                self.cursor_end += 1
                self.eof_reached = True
                return '$', line_changed
                
            self.curr_line = new_line
            self.cursor_end = -1
            self.cursor_start = 0
            self.line_num += 1
            line_changed = True

        self.cursor_end += 1
        return self.curr_line[self.cursor_end], line_changed

    @staticmethod
    def is_parsable_token(token_type_id: int):
        return token_type_id not in [5, 6]  # Comments and whitespace are not parsable

    def get_next_token(self, write_to_file=True):
        self.comment_line_num = -1
        current_state = 0
        
        while self.states[current_state].terminal_type == 0:
            next_char, line_changed = self.read_next_char()

            if current_state == 13 and self.comment_line_num == -1 and self.cursor_end - self.cursor_start == 6:
                self.comment_text = self.curr_line[self.cursor_start: self.cursor_end + 1]
                self.comment_line_num = self.line_num

            if line_changed:
                self.need_line_update = True
                
            next_state = self.states[current_state].get_next_state(next_char)
            
            if next_state == 10:
                next_state = -1
                current_state = 10
                self.cursor_end -= 1
                
            if next_state == 0:
                return ('eof', '$'), self.line_num + 1
                
            if next_state == -1:
                self.handle_error(current_state, next_char)
                self.cursor_start = self.cursor_end + 1
                return self.get_next_token()

            current_state = next_state

        if self.states[current_state].terminal_type == 2:
            self.cursor_end -= 1

        lexeme = self.curr_line[self.cursor_start: self.cursor_end + 1]
        token_type_id = self.states[current_state].token_type_id

        if token_type_id == 2:  # ID token type
            if lexeme in self.reserved_keywords:
                token_type_id = 3  # Change to KEYWORD type

        self.cursor_start = self.cursor_end + 1

        if LexicalAnalyzer.is_parsable_token(token_type_id):
            token = self.token_types[token_type_id], lexeme
            
            if write_to_file:
                self.write_to_symbol_table(token)
                self.write_to_output(token)
                
            self.add_to_symbol_table(token)
            return token, self.line_num
        else:
            return self.get_next_token()

    def handle_error(self, state_id: int, char: str):
        lexeme = self.curr_line[self.cursor_start: self.cursor_end + 1]
        
        if state_id == 13 or state_id == 14:
            lexeme = self.comment_text
            self.error_list.append([self.comment_line_num, lexeme + "...", self.states[state_id].get_error()])
            return
            
        if state_id == 11 and char != "/":
            self.error_list.append([self.line_num, lexeme, "Invalid input"])
            return

        self.error_list.append([self.line_num, lexeme, self.states[state_id].get_error()])

    def add_to_symbol_table(self, token):
        type_id, lexeme = token
        
        if type_id == "ID":
            if lexeme not in self.identifiers_list:
                self.identifiers_list.append(lexeme)

    def write_to_symbol_table(self, token):
        type_id, lexeme = token
        
        if type_id != "KEYWORD" and type_id != "ID":
            return
            
        text = ""
        separator = ".\t"

        if not self.symbol_table_ready:
            for keyword in self.reserved_keywords:
                self.symbol_table_pos += 1
                text += str(self.symbol_table_pos) + separator + keyword + "\n"
            self.symbol_table_ready = True

        if type_id == "ID":
            if lexeme not in self.identifiers_list:
                self.symbol_table_pos += 1
                text += str(self.symbol_table_pos) + separator + lexeme + "\n"

        if text:
            self.symbol_table_file.write(text)

    def write_to_output(self, token):
        type_id, lexeme = token
        text = ""
        
        if self.need_line_update:
            self.need_line_update = False
            if self.line_num != 1:
                text += "\n"
            text += str(self.line_num) + ".\t"
        else:
            text += " "
            
        text += "(" + type_id + ", " + lexeme + ")"
        self.output_file.write(text)

    def write_errors(self):
        if not self.error_list:
            self.lexical_errors_file.write("There is no lexical error.")
            return
            
        text = ""
        i = 0
        
        while i < len(self.error_list):
            line_num = self.error_list[i][0]
            text += str(line_num) + ".\t(" + self.error_list[i][1] + ", " + self.error_list[i][2] + ") "
            
            i += 1
            while i < len(self.error_list) and self.error_list[i][0] == line_num:
                text += "(" + self.error_list[i][1] + ", " + self.error_list[i][2] + ") "
                i += 1

            text = text[:-1] + "\n"

        self.lexical_errors_file.write(text)
