import os
import shutil
import subprocess
import filecmp
import glob

# Base paths
project_dir = os.path.dirname(os.path.abspath(__file__))
test_dir = os.path.join(project_dir, 'phase2 - testcases')

# Compare two files
def compare_files(file1, file2):
    try:
        # Read and normalize the contents of both files
        with open(file1, 'r') as f1, open(file2, 'r') as f2:
            content1 = f1.read().strip()
            content2 = f2.read().strip()
            
            # Normalize line endings
            content1 = content1.replace('\r\n', '\n')
            content2 = content2.replace('\r\n', '\n')
            
            # Compare normalized contents
            return content1 == content2
    except Exception as e:
        print(f"Error comparing files: {e}")
        return False

# Run a test case
def run_test(test_case):
    print(f"Running test {test_case}...")
    
    # Copy input file to current directory
    input_file = os.path.join(test_dir, test_case, 'input.txt')
    current_input = os.path.join(project_dir, 'input.txt')
    shutil.copy(input_file, current_input)
    print(f"Copied {input_file} to {current_input}")
    
    # Run the syntax error checker
    subprocess.run(['py', 'syntax_error_checker.py', current_input])
    
    # Compare output files
    syntax_errors_output = os.path.join(project_dir, 'syntax_errors.txt')
    syntax_errors_expected = os.path.join(test_dir, test_case, 'syntax_errors.txt')
    
    # Show the contents of both files for debugging
    print(f"\nExpected syntax errors in {test_case}:")
    if os.path.exists(syntax_errors_expected):
        with open(syntax_errors_expected, 'r') as f:
            expected_content = f.read()
            print(expected_content)
    else:
        print("Expected file not found!")
    
    print(f"\nActual syntax errors in {test_case}:")
    if os.path.exists(syntax_errors_output):
        with open(syntax_errors_output, 'r') as f:
            actual_content = f.read()
            print(actual_content)
    else:
        print("Output file not found!")
    
    # Check if files exist before comparing
    if os.path.exists(syntax_errors_output) and os.path.exists(syntax_errors_expected):
        syntax_match = compare_files(syntax_errors_output, syntax_errors_expected)
        print(f"Syntax errors match: {syntax_match}")
    else:
        syntax_match = False
        print(f"Warning: One or both syntax_errors.txt files don't exist:")
        print(f"  - Output exists: {os.path.exists(syntax_errors_output)}")
        print(f"  - Expected exists: {os.path.exists(syntax_errors_expected)}")
    
    return syntax_match

def main():
    # Make sure syntax_error_checker.py is in the right location
    if not os.path.exists('syntax_error_checker.py'):
        print("Error: syntax_error_checker.py not found!")
        return
    
    # Run tests
    test_cases = [f"T{i}" for i in range(1, 6)]  # T1 to T5
    results = {}
    
    for test_case in test_cases:
        results[test_case] = run_test(test_case)
    
    # Print results
    print("\nTest Results:")
    print("="*50)
    for test_case, result in results.items():
        print(f"Test {test_case}:")
        print(f"  Syntax Errors Match: {'✓' if result else '✗'}")
        print("-"*50)

if __name__ == "__main__":
    main()
